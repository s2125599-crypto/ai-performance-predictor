from pathlib import Path
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.enum.section import WD_SECTION
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from pptx import Presentation
from pptx.util import Inches as PInches, Pt as PPt
from pptx.enum.text import PP_ALIGN
from pptx.enum.shapes import MSO_SHAPE
from pptx.dml.color import RGBColor as PRGB
from PIL import Image, ImageDraw, ImageFont
import pandas as pd
import json, os, textwrap

BASE=Path('/mnt/data/NITRA_AI_Student_Performance_Project')
FIG=BASE/'figures'; STATIC=BASE/'static'
logo=STATIC/'nitra_logo.png'
meta=json.loads((BASE/'evaluation.json').read_text())
comparison=pd.read_csv(BASE/'data/model_comparison.csv')
fi=pd.read_csv(BASE/'data/feature_importance.csv')

# --------- Helper fonts for screenshots ---------
def font(size,bold=False):
    paths=['/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf' if bold else '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf']
    for p in paths:
        if os.path.exists(p): return ImageFont.truetype(p,size)
    return ImageFont.load_default()

# --------- Generate browser-like UI images for report/PPT ---------
logo_im=Image.open(logo).convert('RGB')
def make_ui(path, result=None):
    W,H=1400,900
    im=Image.new('RGB',(W,H),(244,248,251)); d=ImageDraw.Draw(im)
    # header
    d.rectangle([0,0,W,120],fill='white')
    d.rectangle([0,116,W,120],fill=(6,150,215))
    li=logo_im.copy(); li.thumbnail((105,105)); im.paste(li,(35,8))
    d.text((165,24),'AI-Based Student Performance Predictor',font=font(32,True),fill=(23,33,43))
    d.text((165,68),'NITRA Technical Campus • CSE (AI/ML) Mini Project',font=font(19),fill=(95,108,120))
    # card
    d.rounded_rectangle([60,160,W-60,H-55],radius=22,fill='white',outline=(225,231,237),width=2)
    d.text((90,190),'Enter Academic Indicators',font=font(28,True),fill=(23,33,43))
    d.rounded_rectangle([90,232,680,272],radius=20,fill=(250,252,254),outline=(215,224,231),width=1)
    d.text((110,241),'Student: Ujjwal Srivastava  •  Roll No. 2508021530055',font=font(16),fill=(75,88,100))
    fields=[('Attendance (%)','82'),('Internal Marks / 30','23'),('Assignment Marks / 50','41'),('Study Hours / Day','4'),('Previous Score (%)','72'),('Backlogs','0'),('Absences','6')]
    x0,y0=90,305
    for i,(lab,val) in enumerate(fields):
        col=i%2; row=i//2; x=x0+col*610; y=y0+row*105
        d.text((x,y),lab,font=font(17,True),fill=(23,33,43))
        d.rounded_rectangle([x,y+31,x+540,y+76],radius=10,fill='white',outline=(201,212,222),width=2)
        d.text((x+14,y+42),val,font=font(16),fill=(40,51,62))
    d.rounded_rectangle([90,690,320,745],radius=10,fill=(6,150,215))
    d.text((130,705),'Predict Performance',font=font(18,True),fill='white')
    if result:
        d.rounded_rectangle([90,770,W-90,H-80],radius=14,fill=(242,250,255),outline=(6,150,215),width=3)
        d.text((115,792),f'Predicted Category: {result}',font=font(25,True),fill=(11,110,159))
        d.text((115,830),'Model confidence: 68.3%   •   Suggested actions: maintain attendance and revision routine.',font=font(16),fill=(69,80,92))
    im.save(path)

make_ui(FIG/'app_input_preview.png')
make_ui(FIG/'app_result_preview.png','Good')

# --------- Architecture image ---------
arch=Image.new('RGB',(1400,500),'white'); ad=ImageDraw.Draw(arch)
boxes=[('Student Inputs',(50,180,310,320)),('Data Validation\n& Preprocessing',(390,180,650,320)),('ML Model\nSelection',(730,180,990,320)),('Prediction\n& Confidence',(1070,180,1330,320))]
for text,(x1,y1,x2,y2) in boxes:
    ad.rounded_rectangle([x1,y1,x2,y2],radius=18,fill=(246,250,253),outline=(6,150,215),width=4)
    lines=text.split('\n')
    for j,line in enumerate(lines):
        bbox=ad.textbbox((0,0),line,font=font(22,True)); tw=bbox[2]
        ad.text(((x1+x2-tw)/2, y1+50+j*36),line,font=font(22,True),fill=(23,33,43))
for x in [310,650,990]:
    ad.line([x+5,250,x+75,250],fill=(211,39,47),width=6)
    ad.polygon([(x+75,250),(x+55,238),(x+55,262)],fill=(211,39,47))
ad.text((520,70),'System Architecture / Workflow',font=font(34,True),fill=(23,33,43))
arch.save(FIG/'architecture.png')

# --------- DOCX helpers ---------
def shade_cell(cell, fill):
    tcPr=cell._tc.get_or_add_tcPr(); shd=OxmlElement('w:shd'); shd.set(qn('w:fill'),fill); tcPr.append(shd)
def set_cell_text(cell, text, bold=False, color=None, size=10):
    cell.text=''
    p=cell.paragraphs[0]; r=p.add_run(str(text)); r.bold=bold; r.font.size=Pt(size)
    if color: r.font.color.rgb=RGBColor(*color)
    cell.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER

def add_page_number(paragraph):
    run=paragraph.add_run(); fldChar1=OxmlElement('w:fldChar'); fldChar1.set(qn('w:fldCharType'),'begin'); instrText=OxmlElement('w:instrText'); instrText.text='PAGE'; fldChar2=OxmlElement('w:fldChar'); fldChar2.set(qn('w:fldCharType'),'end'); run._r.append(fldChar1); run._r.append(instrText); run._r.append(fldChar2)

def add_figure(doc,path,caption,width=6.2):
    p=doc.add_paragraph(); p.alignment=WD_ALIGN_PARAGRAPH.CENTER
    p.add_run().add_picture(str(path),width=Inches(width))
    cap=doc.add_paragraph(); cap.alignment=WD_ALIGN_PARAGRAPH.CENTER
    r=cap.add_run(caption); r.italic=True; r.font.size=Pt(9); r.font.color.rgb=RGBColor(90,100,110)

def add_bullets(doc, items):
    for item in items:
        doc.add_paragraph(item, style='List Bullet')

doc=Document()
sec=doc.sections[0]
sec.top_margin=Inches(0.65); sec.bottom_margin=Inches(0.65); sec.left_margin=Inches(0.8); sec.right_margin=Inches(0.8)
styles=doc.styles
styles['Normal'].font.name='Arial'; styles['Normal'].font.size=Pt(10.5)
for s in ['Title','Heading 1','Heading 2','Heading 3']:
    styles[s].font.name='Arial'
styles['Heading 1'].font.size=Pt(16); styles['Heading 1'].font.color.rgb=RGBColor(6,110,160)
styles['Heading 2'].font.size=Pt(13); styles['Heading 2'].font.color.rgb=RGBColor(211,39,47)
styles['Title'].font.size=Pt(22)

# header/footer
header=sec.header.paragraphs[0]; header.alignment=WD_ALIGN_PARAGRAPH.RIGHT
header.add_run('NITRA Technical Campus | AI/ML Mini Project').font.size=Pt(8)
footer=sec.footer.paragraphs[0]; footer.alignment=WD_ALIGN_PARAGRAPH.CENTER
footer.add_run('Ujjwal Srivastava | Roll No. 2508021530055 | Page '); add_page_number(footer)

# Cover
p=doc.add_paragraph(); p.alignment=WD_ALIGN_PARAGRAPH.CENTER
p.add_run().add_picture(str(logo),width=Inches(1.55))
p=doc.add_paragraph(); p.alignment=WD_ALIGN_PARAGRAPH.CENTER
r=p.add_run('NITRA TECHNICAL CAMPUS'); r.bold=True; r.font.size=Pt(20); r.font.color.rgb=RGBColor(6,110,160)
p=doc.add_paragraph(); p.alignment=WD_ALIGN_PARAGRAPH.CENTER
r=p.add_run('MINI PROJECT REPORT'); r.bold=True; r.font.size=Pt(18); r.font.color.rgb=RGBColor(211,39,47)
p=doc.add_paragraph(); p.alignment=WD_ALIGN_PARAGRAPH.CENTER
r=p.add_run('AI-BASED STUDENT PERFORMANCE PREDICTION SYSTEM'); r.bold=True; r.font.size=Pt(24); r.font.color.rgb=RGBColor(23,33,43)
for line in ['Submitted by','Ujjwal Srivastava','Roll No.: 2508021530055','B.Tech. CSE (AI/ML)','Academic Session: 2026–27']:
    p=doc.add_paragraph(); p.alignment=WD_ALIGN_PARAGRAPH.CENTER
    rr=p.add_run(line); rr.font.size=Pt(12 if line!='Ujjwal Srivastava' else 16); rr.bold=(line=='Ujjwal Srivastava')
doc.add_paragraph(); p=doc.add_paragraph(); p.alignment=WD_ALIGN_PARAGRAPH.CENTER; p.add_run('Department of Computer Science & Engineering').font.size=Pt(11)
doc.add_page_break()

# Declaration
for title, text in [
('DECLARATION','I, Ujjwal Srivastava (Roll No. 2508021530055), declare that this mini project report titled “AI-Based Student Performance Prediction System” is prepared for academic purposes under the guidance of the concerned faculty. The work is presented as a prototype and all externally sourced research materials are acknowledged in the references.'),
('CERTIFICATE','This is to certify that Ujjwal Srivastava, Roll No. 2508021530055, has prepared the mini project titled “AI-Based Student Performance Prediction System” as part of the academic requirements of B.Tech. CSE (AI/ML) at NITRA Technical Campus. The project demonstrates data preprocessing, supervised machine learning, model evaluation and web-based deployment.'),
('ACKNOWLEDGEMENT','I sincerely thank the faculty members and project guide of NITRA Technical Campus for their guidance and academic support. I also acknowledge the UCI Machine Learning Repository and the official documentation of the software libraries used in this prototype.'),
('ABSTRACT','This project presents a web-based machine-learning prototype that classifies student academic performance as Low, Average, Good or Excellent. Seven indicators are used: attendance percentage, internal marks, assignment marks, study hours per day, previous score, backlogs and absences. Four supervised classifiers—Logistic Regression, Decision Tree, Random Forest and Support Vector Machine—are compared on a held-out demonstration dataset. The best-performing model in the supplied reproducible run is saved and served through a Flask application. The project also provides confidence information and basic study-oriented suggestions. Because the included dataset is synthetic, the evaluation values are only a demonstration benchmark and must not be interpreted as actual NITRA student outcomes.'),
]:
    doc.add_heading(title,level=1); doc.add_paragraph(text); doc.add_page_break()

# TOC-like contents
contents=[
'1. Introduction','2. Problem Statement','3. Objectives and Scope','4. Literature Review','5. Proposed System','6. System Architecture','7. Dataset and Data Preparation','8. Feature Engineering and Label Definition','9. Machine Learning Models','10. Model Evaluation','11. Web Application Implementation','12. User Interface','13. Testing','14. Results and Discussion','15. Advantages','16. Limitations and Ethical Considerations','17. Future Scope','18. Conclusion','19. References','20. Appendix A – Folder Structure','21. Appendix B – Viva Questions']
doc.add_heading('TABLE OF CONTENTS',level=1)
for c in contents: doc.add_paragraph(c)
doc.add_page_break()

# Chapter sections
chapters=[
('1. Introduction',[
('Background','Educational institutions generate large amounts of academic information such as assessment marks, attendance, study habits and previous results. Machine learning can be used to discover relationships in structured data and provide an early performance indicator. The purpose of this mini project is to demonstrate that workflow in a compact, deployable application.'),
('Project Motivation','Students may benefit from early identification of weak academic patterns. A small prediction interface can help demonstrate how academic analytics moves from raw inputs to a model-based output and then to an actionable suggestion layer.'),
('Project Context','This is an academic prototype for CSE (AI/ML). It is not intended to make high-stakes decisions about students and should not be treated as a substitute for teachers or formal evaluation.')]),
('2. Problem Statement',[
('Problem','Manual inspection of attendance and marks is often repetitive and reactive. There is a need for a small system that can process multiple indicators consistently and provide an interpretable performance category for demonstration and early-warning research.'),
('Need for Automation','A machine-learning workflow can automate feature handling, model inference and presentation of a standardized result.' )]),
('3. Objectives and Scope',[
('Objectives','Develop a labelled dataset for a controlled prototype; compare supervised classifiers; select and save a model; build a Flask-based UI; report metrics; provide simple suggestions; document limitations and future deployment requirements.'),
('Scope','The scope covers tabular academic indicators, multiclass classification, offline model training and local web deployment. It does not cover institutional SSO, production databases, high-stakes decisions, or live student records.')]),
('4. Literature Review',[
('Student Performance Dataset','The UCI Student Performance dataset is a well-known reference dataset for educational data mining. UCI reports 649 instances and 30 attributes, including study-related, family and academic variables. The final grade field G3 ranges from 0 to 20 and is documented as the output target.'),
('Machine Learning Approach','Common supervised approaches for tabular classification include linear models, decision trees, ensemble trees and support vector machines. The project therefore compares Logistic Regression, Decision Tree, Random Forest and SVM instead of assuming a single algorithm is always best.'),
('Web Deployment','The application uses Flask so the same Python environment can load the trained model and expose a browser-accessible prediction form.')]),
('5. Proposed System',[
('Overview','The proposed system accepts seven numerical academic indicators, validates ranges, converts them to a Pandas DataFrame with the expected feature order, loads the trained model, predicts the performance category, calculates model confidence when probability output is available, and generates rule-based study suggestions.'),
('Key Modules','Data generation and storage; model training and selection; model serialization; Flask server; HTML/CSS user interface; evaluation and reporting.')]),
('6. System Architecture',[]),
('7. Dataset and Data Preparation',[
('Demonstration Dataset','The included dataset contains 800 synthetic records generated with a fixed random seed. Synthetic data is used so the package is reproducible without exposing personal student information.'),
('Research Extension','For a research-backed extension, the UCI Student Performance dataset can be used. The UCI documentation identifies 649 records and variables such as study time, failures, absences and grades G1, G2 and G3. The final grade G3 is the stated output target in that dataset.'),
('Preprocessing','The project performs a fixed train/test split using stratification. Logistic Regression and SVM use StandardScaler within a pipeline. The tree-based models operate directly on the numeric features. Input validation in the Flask app rejects out-of-range values.')]),
('8. Feature Engineering and Label Definition',[
('Features Used','Attendance percentage, internal marks out of 30, assignment marks out of 50, study hours per day, previous score percentage, number of backlogs, and absences.'),
('Target Categories','The synthetic generator maps a continuous latent academic score to four categories: Low, Average, Good and Excellent. This is a prototype label definition; a real institutional project should define categories using the institution’s grading policy or directly predict a numeric final score.'),
('Why These Features','They represent commonly interpretable academic indicators. They are also easy to collect in a mini-project interface.')]),
('9. Machine Learning Models',[
('Logistic Regression','A linear classification method used as a transparent baseline. Because the inputs have different scales, StandardScaler is applied within a pipeline.'),
('Decision Tree','A rule-based tree classifier that recursively separates examples using feature thresholds. It is simple to visualize but can overfit without constraints.'),
('Random Forest','An ensemble of decision trees whose predictions are aggregated. It is a common strong baseline for tabular data and can capture nonlinear relationships.'),
('Support Vector Machine','A margin-based classifier that can model nonlinear decision boundaries through kernels. Standardization is included in its pipeline.')]),
('10. Model Evaluation',[
('Evaluation Protocol','The dataset is divided into 80% training and 20% test records using a fixed random state and stratification. Accuracy, weighted precision, weighted recall and weighted F1-score are computed on the unseen test set.'),
('Model Selection','The supplied demonstration run selects the model with the strongest weighted F1-score. The exact values are stored in data/model_comparison.csv and evaluation.txt, so the numbers can be independently checked by rerunning train_model.py.'),
('Important Interpretation','These values describe only the synthetic demonstration dataset. They do not estimate actual performance for NITRA students or any real institution.')]),
('11. Web Application Implementation',[
('Backend','Flask loads model.joblib at startup. A POST request retrieves the seven fields, validates ranges, constructs the feature vector and calls the trained model.'),
('Frontend','A responsive HTML/CSS form collects the inputs and displays the prediction, confidence estimate and improvement suggestions.'),
('Persistence','The model is serialized using Joblib. The current prototype does not persist student identities or live records.')]),
('12. User Interface',[]),
('13. Testing',[
('Functional Tests','Valid input should produce a prediction and suggested actions. Invalid attendance, marks, study hours or negative counts should produce an input error.'),
('Model Tests','The training script should complete successfully, save model.joblib and create model comparison metrics. A deterministic random seed makes the demonstration reproducible.'),
('Browser Test','The local application is intended to run at http://127.0.0.1:5000 after installing requirements and training the model.')]),
('14. Results and Discussion',[
('Demonstration Result',f"The supplied run uses {meta['samples']} records with {meta['test_samples']} held out for evaluation. The selected model is {meta['best_model']}. Its hold-out accuracy is {meta['accuracy']*100:.2f}%, weighted precision is {meta['precision']:.3f}, weighted recall is {meta['recall']:.3f}, and weighted F1-score is {meta['f1']:.3f}. These are demonstration results only."),
('Discussion','The model-comparison chart makes it clear why the project evaluates multiple algorithms rather than assuming that a popular algorithm will always be best. Class-wise performance also matters; a single accuracy number can hide weak recall for smaller classes.' )]),
('15. Advantages',[
('Simple Demonstration','The application is easy to understand and run locally.'),
('End-to-End Workflow','It covers data, preprocessing, model comparison, serialization, inference and user interface.'),
('Extensible','The feature schema can be mapped to a real institutional dataset later.')]),
('16. Limitations and Ethical Considerations',[
('Dataset Limitation','The included dataset is synthetic and is not representative of actual NITRA students.'),
('Prediction Limitation','A predicted class is not a guaranteed future outcome and should not be used for punitive decisions.'),
('Privacy','Real student data should be collected only with institutional authorization and appropriate privacy controls. Personal identifiers should be minimized or removed for modeling.'),
('Fairness','Before deployment, performance should be checked across relevant groups and potential bias should be investigated.' )]),
('17. Future Scope',[
('Real Data Integration','Connect a properly authorized, anonymized academic dataset.'),
('Explainable AI','Add feature-level explanations using suitable model interpretation methods.'),
('Dashboard','Provide semester-level trends and cohort analytics.'),
('Production Readiness','Add authentication, database storage, audit logging, deployment controls and model monitoring.')]),
('18. Conclusion',[
('Conclusion','The project demonstrates an end-to-end AI/ML application that classifies student performance using structured academic indicators. It compares several supervised algorithms, stores the selected model, and exposes predictions through a branded Flask interface. The package is suitable for an academic mini-project submission and provides a clear path toward a more rigorous institutional prototype.')]),
]

for title, subs in chapters:
    if title.startswith('6.'):
        doc.add_heading(title,level=1); add_figure(doc,FIG/'architecture.png','Figure: High-level workflow of the proposed system.'); doc.add_paragraph('The architecture separates data entry, preprocessing, model inference and the user-facing result layer. This modular structure makes testing and future replacement of the model easier.'); doc.add_page_break(); continue
    if title.startswith('12.'):
        doc.add_heading(title,level=1); add_figure(doc,FIG/'app_input_preview.png','Figure: Branded input-page preview used for the prototype documentation.'); add_figure(doc,FIG/'app_result_preview.png','Figure: Example prediction-result preview.'); doc.add_paragraph('The images are documentation previews of the local interface design. They are included to show the intended presentation of the project.'); doc.add_page_break(); continue
    doc.add_heading(title,level=1)
    for h,body in subs:
        doc.add_heading(h,level=2); doc.add_paragraph(body)
    if title in ['7. Dataset and Data Preparation','10. Model Evaluation','14. Results and Discussion']:
        if title.startswith('7.'):
            add_figure(doc,FIG/'class_distribution.png','Figure: Class distribution in the synthetic demonstration dataset.')
        if title.startswith('10.'):
            add_figure(doc,FIG/'model_accuracy.png','Figure: Hold-out test accuracy comparison across classifiers.')
            add_figure(doc,FIG/'confusion_matrix.png','Figure: Confusion matrix of the selected model on the demonstration test set.')
        if title.startswith('14.'):
            add_figure(doc,FIG/'attendance_by_category.png','Figure: Mean attendance by synthetic performance category.')
    doc.add_page_break()

# References
refs=[
'UCI Machine Learning Repository. Student Performance Dataset, dataset 320. https://archive.ics.uci.edu/dataset/320/student+performance',
'Pedregosa, F. et al. (2011). Scikit-learn: Machine Learning in Python. Journal of Machine Learning Research, 12, 2825–2830.',
'Flask Documentation. Pallets Projects. https://flask.palletsprojects.com/',
'Joblib Documentation. https://joblib.readthedocs.io/',
'Python Documentation. https://docs.python.org/'
]
doc.add_heading('19. References',level=1)
for r in refs: doc.add_paragraph(r,style='List Number')
doc.add_page_break()

doc.add_heading('20. Appendix A – Folder Structure',level=1)
folder='''NITRA_AI_Student_Performance_Project/\n├── app.py\n├── train_model.py\n├── build_project.py\n├── model.joblib\n├── requirements.txt\n├── README.md\n├── DATASET_NOTE.md\n├── Viva_QA.md\n├── data/\n│   ├── student_performance_demo.csv\n│   ├── model_comparison.csv\n│   └── feature_importance.csv\n├── figures/\n│   ├── architecture.png\n│   ├── class_distribution.png\n│   ├── model_accuracy.png\n│   ├── confusion_matrix.png\n│   ├── attendance_by_category.png\n│   ├── app_input_preview.png\n│   └── app_result_preview.png\n├── templates/index.html\n└── static/nitra_logo.png'''
doc.add_paragraph(folder)
doc.add_paragraph('The ZIP package additionally contains the report and presentation files. The supplied college logo is included in the web application and presentation/report title pages.')
doc.add_page_break()

doc.add_heading('21. Appendix B – Viva Questions',level=1)
qa=(BASE/'Viva_QA.md').read_text()
for block in qa.split('\n\n')[1:]:
    if block.strip(): doc.add_paragraph(block.replace('**',''))

report=BASE/'Project_Report.docx'; doc.save(report)

# --------- PPT ---------
prs=Presentation(); prs.slide_width=PInches(13.333); prs.slide_height=PInches(7.5)
blue=PRGB(6,150,215); red=PRGB(211,39,47); dark=PRGB(23,33,43); gray=PRGB(95,108,120); light=PRGB(245,248,251)

def add_header(slide,title):
    slide.shapes.add_shape(MSO_SHAPE.RECTANGLE,0,0,prs.slide_width,PInches(.12)).fill.solid(); slide.shapes[-1].fill.fore_color.rgb=blue; slide.shapes[-1].line.fill.background()
    tb=slide.shapes.add_textbox(PInches(.6),PInches(.35),PInches(11.8),PInches(.55)); p=tb.text_frame.paragraphs[0]; p.text=title; p.font.size=PPt(28); p.font.bold=True; p.font.color.rgb=dark
    slide.shapes.add_picture(str(logo),PInches(12.25),PInches(.18),height=PInches(.75))

def add_bullets_slide(title, bullets, image=None, two_col=False):
    slide=prs.slides.add_slide(prs.slide_layouts[6]); add_header(slide,title)
    if image:
        slide.shapes.add_picture(str(image),PInches(.65),PInches(1.25),width=PInches(6.1))
        x=PInches(7.0); w=PInches(5.7)
    else:
        x=PInches(.85); w=PInches(11.7)
    tb=slide.shapes.add_textbox(x,PInches(1.35),w,PInches(5.5)); tf=tb.text_frame; tf.word_wrap=True
    for i,b in enumerate(bullets):
        p=tf.paragraphs[0] if i==0 else tf.add_paragraph(); p.text=b; p.level=0; p.font.size=PPt(20); p.space_after=PPt(11); p.font.color.rgb=dark
    return slide

# Cover
s=prs.slides.add_slide(prs.slide_layouts[6]); s.background.fill.solid(); s.background.fill.fore_color.rgb=light
s.shapes.add_shape(MSO_SHAPE.RECTANGLE,0,0,PInches(.28),prs.slide_height).fill.solid(); s.shapes[-1].fill.fore_color.rgb=red; s.shapes[-1].line.fill.background()
s.shapes.add_picture(str(logo),PInches(.65),PInches(.55),height=PInches(1.25))
t=s.shapes.add_textbox(PInches(2.35),PInches(.65),PInches(10.2),PInches(2.0)); p=t.text_frame.paragraphs[0]; p.text='AI-BASED STUDENT\nPERFORMANCE PREDICTION SYSTEM'; p.font.size=PPt(32); p.font.bold=True; p.font.color.rgb=dark
sub=s.shapes.add_textbox(PInches(2.38),PInches(2.6),PInches(9.8),PInches(2.2)); tf=sub.text_frame
for i,txt in enumerate(['Mini Project Presentation','Ujjwal Srivastava','Roll No.: 2508021530055','NITRA Technical Campus','B.Tech. CSE (AI/ML) • Academic Session 2026–27']):
    p=tf.paragraphs[0] if i==0 else tf.add_paragraph(); p.text=txt; p.font.size=PPt(21 if i in [0,1] else 18); p.font.bold=(i<2); p.font.color.rgb=(red if i==0 else gray); p.space_after=PPt(8)

add_bullets_slide('1. Introduction',[
'Academic performance depends on multiple measurable indicators such as attendance, assessment scores and study habits.',
'The project demonstrates how supervised machine learning can turn those indicators into a performance category.',
'The system is an academic prototype and is not intended to replace teachers or formal evaluation.'
])
add_bullets_slide('2. Problem Statement',[
'Manual review of academic indicators can be repetitive and reactive.',
'A compact ML system can provide a standardized early performance signal.',
'The goal is to combine prediction with a simple, understandable web interface.'
])
add_bullets_slide('3. Objectives',[
'Create a reproducible labelled dataset for a controlled prototype.',
'Compare multiple supervised classification algorithms.',
'Save the selected model and expose it through Flask.',
'Provide a clear result, model confidence and study-oriented suggestions.',
'Document evaluation, limitations and future scope.'
])
add_bullets_slide('4. Research & Dataset Basis',[
'UCI Student Performance is used as the research reference dataset.',
'UCI reports 649 records and 30 attributes, including study time, failures, absences and grades G1/G2/G3.',
'The bundled project dataset is synthetic so it can run offline without exposing student records.',
'For a real version, an authorized anonymized institutional dataset should be used.'
],image=FIG/'class_distribution.png')
add_bullets_slide('5. Features Used',[
'Attendance percentage', 'Internal marks / 30', 'Assignment marks / 50', 'Study hours per day', 'Previous score percentage', 'Number of backlogs', 'Absences'
])
add_bullets_slide('6. System Architecture',[
'Data entry → validation → feature vector → ML model → prediction + confidence → suggestions',
'Modular design keeps the web layer independent of the model training script.'
],image=FIG/'architecture.png')
add_bullets_slide('7. Data Preparation',[
'800 synthetic records in the supplied demonstration dataset.',
'80/20 stratified train-test split.',
'Input range validation in the Flask application.',
'StandardScaler is used inside pipelines for Logistic Regression and SVM.'
])
add_bullets_slide('8. Algorithms Compared',[
'Logistic Regression — linear baseline',
'Decision Tree — interpretable rule-based model',
'Random Forest — ensemble of decision trees',
'SVM — margin-based nonlinear classifier'
],image=FIG/'model_accuracy.png')
add_bullets_slide('9. Model Evaluation',[
'Accuracy, weighted precision, weighted recall and weighted F1-score are reported.',
'The model selection rule uses the strongest weighted F1-score in the reproducible run.',
'Current selected model: '+meta['best_model']+f' with {meta["accuracy"]*100:.2f}% hold-out accuracy on the synthetic demo set.',
'This result must not be interpreted as real-world or college-specific accuracy.'
],image=FIG/'confusion_matrix.png')
add_bullets_slide('10. Web Application',[
'Flask backend loads model.joblib.',
'HTML/CSS form collects the seven features.',
'Invalid ranges are rejected before inference.',
'Prediction page displays category, confidence and suggestions.'
],image=FIG/'app_input_preview.png')
add_bullets_slide('11. Example Output',[
'Example category: Good',
'Confidence is model-derived when the classifier provides class probabilities.',
'Suggestions are generated from simple transparent rules such as attendance and backlog thresholds.',
'The result is advisory, not a guaranteed outcome.'
],image=FIG/'app_result_preview.png')
add_bullets_slide('12. Testing',[
'Functional validation for valid and invalid numeric ranges.',
'Model training creates a serialized model and evaluation files.',
'Rerunning train_model.py reproduces the demonstration training workflow.',
'Local browser test target: http://127.0.0.1:5000'
])
add_bullets_slide('13. Advantages & Limitations',[
'Advantages: simple, end-to-end, demonstrable, extensible, modular.',
'Limitations: synthetic demo data, no college-specific validation, possible class imbalance, no causal interpretation.',
'Privacy and fairness checks are mandatory before any real deployment.'
])
add_bullets_slide('14. Future Scope',[
'Use authorized anonymized college data.',
'Add explainable AI and probability calibration.',
'Build dashboards and semester trend analysis.',
'Add database, authentication, logging and monitoring.',
'Evaluate fairness and model drift over time.'
])
add_bullets_slide('15. Conclusion',[
'The project demonstrates the complete ML lifecycle from structured inputs to a web-based prediction.',
'It combines data preparation, algorithm comparison, evaluation, model serialization and deployment.',
'The package is suitable for a mini-project submission and can be extended into a research-grade system.'
])
# Q&A slide
add_bullets_slide('16. Viva / Q&A',[
'What is supervised learning?', 'Why compare multiple classifiers?', 'Why is train/test split needed?', 'What is overfitting?', 'Why is the demo dataset synthetic?', 'How would you deploy it in a real college?'
])

ppt=BASE/'Project_Presentation.pptx'; prs.save(ppt)
print('Created',report,ppt)
