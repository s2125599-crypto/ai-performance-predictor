# AI-Based Student Performance Predictor

**Student:** Ujjwal Srivastava  
**Roll No.:** 2508021530055  
**College:** NITRA Technical Campus  
**Branch:** CSE (AI/ML)

## What the project does
A supervised machine-learning prototype classifies a student's performance into **Low, Average, Good, or Excellent** using seven academic indicators: attendance, internal marks, assignment marks, study hours, previous score, backlogs, and absences. A Flask web application provides the prediction interface.

## Data and research note
The included CSV is a **synthetic demonstration dataset** created solely to make the project reproducible without exposing personal student records. It is **not** an institutional dataset and its measured accuracy must not be treated as real-world accuracy.

For research extension, use the **UCI Student Performance** dataset (UCI Machine Learning Repository, dataset 320), which contains 649 student records and includes G1, G2, G3 grades plus academic/social attributes. G3 is the final grade target. Source: https://archive.ics.uci.edu/dataset/320/student+performance

## Run the project
```bash
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
python train_model.py
python app.py
```
Then open `http://127.0.0.1:5000`.

## Model evaluation
Four classifiers are compared: Logistic Regression, Decision Tree, Random Forest and SVM. The best model in the included demonstration run is saved as `model.joblib`. Exact test results are stored in `evaluation.txt`, `evaluation.json`, and `data/model_comparison.csv`.

## Project files
- `app.py` — Flask web application
- `train_model.py` — retrains and selects the best classifier
- `model.joblib` — trained demonstration model
- `data/student_performance_demo.csv` — synthetic demo data
- `data/model_comparison.csv` — comparison metrics
- `figures/` — evaluation figures
- `templates/index.html` — UI
- `static/nitra_logo.png` — supplied college logo
- `Project_Report.docx` — detailed report
- `Project_Presentation.pptx` — PPT
- `Viva_QA.md` — viva preparation

## Ethical / academic note
The system is for educational demonstration. Before real institutional use, student records must be anonymized, authorized, validated, and monitored for privacy, bias, and model drift. Predictions should support—not replace—academic judgement.
