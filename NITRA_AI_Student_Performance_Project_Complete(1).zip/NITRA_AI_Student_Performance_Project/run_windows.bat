@echo off
setlocal
cd /d %~dp0

echo ================================================
echo NITRA AI Student Performance Predictor
 echo ================================================

where python >nul 2>nul
if errorlevel 1 (
  echo Python was not found. Install Python 3.10+ and try again.
  pause
  exit /b 1
)

if not exist .venv (
  echo Creating virtual environment...
  python -m venv .venv
)

call .venv\Scripts\activate.bat

echo Installing required packages...
python -m pip install --upgrade pip
python -m pip install -r requirements.txt

if errorlevel 1 (
  echo Package installation failed.
  pause
  exit /b 1
)

echo Training the machine-learning model...
python train_model.py
if errorlevel 1 (
  echo Model training failed.
  pause
  exit /b 1
)

echo Starting Flask server...
echo Open http://127.0.0.1:5000 in your browser.
python app.py
pause
