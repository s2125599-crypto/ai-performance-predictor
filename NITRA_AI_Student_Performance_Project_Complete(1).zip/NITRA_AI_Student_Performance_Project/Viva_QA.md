# Viva Questions and Suggested Answers

1. **What is the aim of the project?**
   To build a machine-learning prototype that classifies student performance from selected academic indicators and presents the result through a web interface.

2. **Why is this an AI/ML project?**
   The core prediction is learned from labeled data using supervised machine-learning algorithms rather than manually coded rules alone.

3. **What algorithms did you compare?**
   Logistic Regression, Decision Tree, Random Forest and Support Vector Machine.

4. **How did you choose the final model?**
   By comparing hold-out test accuracy, precision, recall and weighted F1-score and selecting the strongest overall result in the reproducible demo run.

5. **Why split the dataset?**
   To evaluate the model on unseen records and reduce the risk of reporting only training performance.

6. **What is overfitting?**
   Overfitting occurs when a model learns patterns specific to the training set and fails to generalize to unseen data.

7. **What is accuracy?**
   Accuracy is the proportion of correctly classified examples among all evaluated examples.

8. **What are precision and recall?**
   Precision measures how many predicted positives are correct; recall measures how many actual positives are detected. For multiclass tasks, they can be averaged across classes.

9. **Why use synthetic data in the package?**
   To keep the project reproducible and avoid distributing personal or institutional student records. It is clearly labeled as synthetic and is not presented as real college data.

10. **Can this predict a student's final marks with certainty?**
    No. It is a statistical prototype. Academic outcomes depend on many factors, and a prediction is not a guarantee.

11. **How would you make it suitable for a real college?**
    Use authorized anonymized institutional data, validate the model by semester, use cross-validation, monitor drift, assess fairness, and implement access controls and privacy safeguards.

12. **Why is Flask used?**
    Flask is a lightweight Python web framework that can expose the trained model through an HTML interface.

13. **What is the role of StandardScaler?**
    It standardizes numeric features for algorithms such as Logistic Regression and SVM so that variables measured on different scales are more comparable during training.

14. **What is the target variable?**
    One of four categories: Low, Average, Good or Excellent.

15. **What is future scope?**
    Real anonymized college data, probability calibration, explainable AI, dashboards, database integration, alerts, and fairness/privacy evaluation.
