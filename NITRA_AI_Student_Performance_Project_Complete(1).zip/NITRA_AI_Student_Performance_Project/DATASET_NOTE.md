# Dataset Note

## Included dataset
`data/student_performance_demo.csv` contains 800 synthetic records generated with a fixed random seed. It is included to ensure the project runs offline and reproducibly.

## Research dataset for extension
UCI Machine Learning Repository — Student Performance, dataset 320:
https://archive.ics.uci.edu/dataset/320/student+performance

UCI describes 649 records and 30 attributes for secondary-school students, with `G3` (0–20) as the final-grade target. The dataset includes academic and social variables such as study time and failures. In a future version, the application feature schema can be adapted to these fields and the performance labels can be derived from G3.

## Do not claim
Do not claim that the included synthetic dataset represents NITRA students or that its test accuracy predicts actual college outcomes.
